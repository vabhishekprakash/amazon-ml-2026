"""Turn dumped pair scores into a submission, under a chosen decision rule.

Scoring a split costs hours; deciding what to do with the scores costs seconds.
predict_matches.py --dump-scores writes every (entity, target, probability)
triple to disk, and this applies a rule to them and writes the two TSVs. That
means a decision-rule change never requires re-running the feature pass.

Rules:
  greedy           per-entity greedy admission under F0.5 (the current default)
  argmax_greedy    a target may only be claimed by the entity that scores it
                   highest, applied BEFORE admission, then greedy per entity
  threshold        keep every pair at or above --threshold
  argmax_threshold each target goes to its best entity, kept above --threshold
  topk             the best --topk candidates per entity

The argmax rules apply one-to-one before admission, as a hard exclusion, rather
than as a cleanup afterwards where it can only break ties. The training data
licenses it: no Source 2/3 record belongs to two Source 1 entities.

The final submission uses argmax_threshold at 0.70.

Run:
    python src/decide.py --scores outputs/scores/test_f28 --split test \
        --rule argmax_threshold --threshold 0.70 --run-name sub03_final
"""
import argparse
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import config as C
from src import er_io
from src.decision_rules import entity_slices, load_scores

ENCODE = 2_000_000_000


def decode(enc: int) -> str:
    """Encoded target id back to its entity_id string."""
    src, num = divmod(int(enc), ENCODE)
    return f"S{src}-{num}"


def apply_argmax(s1_row, enc_id, prob):
    """Keep only each target's single best entity. Returns a boolean mask."""
    order = np.lexsort((-prob, enc_id))
    first = np.zeros(len(enc_id), dtype=bool)
    e = enc_id[order]
    first[order[np.concatenate(([True], e[1:] != e[:-1]))]] = True
    return first


def greedy_admit(p, ids, k_hat):
    """Admit while p exceeds the running score divided by 1.25."""
    chosen, c, n = [], 0.0, 0
    for j in range(len(p)):
        if n and p[j] <= c / (n + 0.25 * k_hat):
            break
        chosen.append(int(ids[j]))
        c += float(p[j])
        n += 1
    return chosen


def build(rule, s1_row, enc_id, prob, k_hat, threshold, topk):
    """Apply one rule; returns {s1_row: [enc_id, ...]}."""
    if rule in ("argmax_greedy", "argmax_threshold"):
        keep = apply_argmax(s1_row, enc_id, prob)
        s1_row, enc_id, prob = s1_row[keep], enc_id[keep], prob[keep]
        order = np.lexsort((-prob, s1_row))
        s1_row, enc_id, prob = s1_row[order], enc_id[order], prob[order]

    ents, starts, stops = entity_slices(s1_row)
    out = {}
    for row, a, b in zip(ents.tolist(), starts, stops):
        p, ids = prob[a:b], enc_id[a:b]
        if rule in ("greedy", "argmax_greedy"):
            picked = greedy_admit(p, ids, k_hat)
        elif rule in ("threshold", "argmax_threshold"):
            picked = ids[p >= threshold].tolist()
        elif rule == "topk":
            picked = ids[:topk].tolist()
        else:
            raise SystemExit(f"unknown rule {rule}")
        if picked:
            out[row] = picked
    return out


def write_pair(out_dir: Path, split: str, assigned, scored):
    """Write matching_results.tsv and candidate_pairs.tsv in file order."""
    out_dir.mkdir(parents=True, exist_ok=True)
    ids = er_io.parse_source(split, 1)["ids"].tolist()
    with open(out_dir / C.MATCHING_FILE, "w", encoding="utf-8", newline="\n") as f:
        f.write(f"{C.GT_ID_COL}\t{C.GT_MATCH_COL}\n")
        for row, num in enumerate(ids):
            f.write(f"S1-{num}\t{','.join(decode(i) for i in assigned.get(row, ()))}\n")
    with open(out_dir / C.CANDIDATE_FILE, "w", encoding="utf-8", newline="\n") as f:
        f.write(f"{C.GT_ID_COL}\t{C.CANDIDATE_COL}\n")
        for row, num in enumerate(ids):
            f.write(f"S1-{num}\t{','.join(decode(i) for i in scored.get(row, ()))}\n")
    return len(ids)


def main(a) -> None:
    """Load scores, apply the rule, write both files and a summary."""
    s1_row, enc_id, prob = load_scores(Path(a.scores))
    k_hat = a.k_hat
    assigned = build(a.rule, s1_row, enc_id, prob, k_hat, a.threshold, a.topk)

    # candidate_pairs must be what the model scored, so it comes from the dump.
    scored = {}
    ents, starts, stops = entity_slices(s1_row)
    for row, x, y in zip(ents.tolist(), starts, stops):
        scored[row] = enc_id[x:y].tolist()

    out_dir = C.OUT_DIR / "submissions" / a.run_name
    rows = write_pair(out_dir, a.split, assigned, scored)
    n_ids = sum(len(v) for v in assigned.values())
    summary = {"rule": a.rule, "split": a.split, "rows": rows,
               "threshold": a.threshold, "topk": a.topk, "k_hat": k_hat,
               "predicted_ids": n_ids, "ids_per_entity": n_ids / max(rows, 1),
               "entities_with_match": len(assigned),
               "empty_share": 1 - len(assigned) / max(rows, 1)}
    print(json.dumps(summary, indent=2))
    res = C.RESULTS_DIR / a.run_name
    res.mkdir(parents=True, exist_ok=True)
    (res / "decide.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(f"wrote {out_dir}")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--scores", required=True)
    p.add_argument("--split", default="test", choices=["train", "test"])
    p.add_argument("--rule", default="argmax_greedy",
                   choices=["greedy", "argmax_greedy", "threshold", "argmax_threshold", "topk"])
    p.add_argument("--run-name", required=True)
    p.add_argument("--threshold", type=float, default=0.5)
    p.add_argument("--topk", type=int, default=3)
    p.add_argument("--k-hat", type=float, default=3.479,
                   help="expected matches per entity, used by the admission bar")
    main(p.parse_args())
