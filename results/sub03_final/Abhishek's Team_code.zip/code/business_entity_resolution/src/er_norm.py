"""Text normalization and address feature extraction for entity resolution.

Pure functions, no I/O. Everything here must behave the same for every country
label: the rules key on shapes that occur in all of them (digit runs, latin
punctuation, common legal and street abbreviations), never on the country field.
"""
import hashlib
import re
import unicodedata

# Variant -> canonical token. Legal suffixes first, then street words. Kept
# generic so it transfers to a country that never appears in training.
ABBREVIATIONS = {
    # legal form
    "corporation": "corp", "incorporated": "inc", "limited": "ltd",
    "private": "pvt", "company": "co", "societe": "ste", "société": "ste",
    "anonyme": "sa",
    # "&" is stripped as punctuation, so "and" is dropped to match it.
    "and": "",
    # street and address words
    "road": "rd", "street": "st", "avenue": "ave", "boulevard": "blvd",
    "lane": "ln", "drive": "dr", "floor": "fl", "apartment": "apt",
    "building": "bldg", "opposite": "opp", "near": "nr", "saint": "st",
    "sainte": "st", "number": "no", "house": "h", "block": "blk",
    "sector": "sec", "phase": "ph", "nagar": "ngr", "colony": "col",
}

# Characters that carry no identity: punctuation injected as noise
# ("[LLC]", "-- Name", "<< Name", "B+ Retail"), quotes, brackets, pipes.
_URL = re.compile(r"\b(?:https?://|www\.)\S+|\b\S+\.(?:com|in|net|org|co)\b", re.I)
_SCHEME = re.compile(r"\b(?:https?://|www\.)", re.I)
_TLD = re.compile(r"\.(?:com|in|net|org|co)\b", re.I)
_PUNCT = re.compile(r"[^\w\s]+", re.UNICODE)
_SPACE = re.compile(r"\s+")
_DIGIT_RUN = re.compile(r"\d+")


def strip_accents(text: str) -> str:
    """Remove combining marks so accented and plain spellings collapse together."""
    return "".join(ch for ch in unicodedata.normalize("NFKD", text)
                   if not unicodedata.combining(ch))


def normalize_name(text: str) -> str:
    """Canonical form of a business name.

    Lowercases, drops a trailing URL, removes punctuation, strips accents, and
    maps known abbreviation variants onto one spelling.

    A name that is nothing but a domain ("heassociates.com" — about 3.5% of
    Source 2) would be erased by the URL rule, so when URL removal leaves
    nothing the domain body is kept instead. Returns "" only when the name
    carries no word characters at all.
    """
    if not text:
        return ""
    lowered = text.lower()
    out = _URL.sub(" ", lowered)
    if not out.strip():  # the whole name was a URL: keep the domain body
        out = _TLD.sub(" ", _SCHEME.sub(" ", lowered))
    out = _PUNCT.sub(" ", strip_accents(out))
    tokens = [ABBREVIATIONS.get(tok, tok) for tok in _SPACE.sub(" ", out).split()]
    return " ".join(tok for tok in tokens if tok)


def token_sort(normalized: str) -> str:
    """Reorder tokens alphabetically so word-order swaps collapse to one key."""
    return " ".join(sorted(normalized.split()))


def house_numbers(address: str) -> frozenset:
    """Integer values of every digit run of 1-6 digits in the address.

    Leading zeros are dropped so "008138 MARYDEAN AVE" and "8138 Marydean Ave"
    agree. Runs longer than 6 digits are phone-like and are ignored.
    """
    return frozenset(int(run) for run in _DIGIT_RUN.findall(address or "")
                     if 1 <= len(run) <= 6)


def postcodes(address: str) -> frozenset:
    """Digit runs of exactly 5 or 6 characters, kept as strings.

    Covers US ZIP (5), India PIN (6) and France code postal (5). Leading zeros
    are significant here, so these stay strings.
    """
    return frozenset(run for run in _DIGIT_RUN.findall(address or "")
                     if len(run) in (5, 6))


def address_tokens(address: str) -> frozenset:
    """Normalized non-numeric word tokens of an address, for overlap features."""
    norm = normalize_name(address)
    return frozenset(tok for tok in norm.split() if not tok.isdigit())


def number_word_keys(address: str, span: int = 2, min_len: int = 1) -> frozenset:
    """'number word' keys pairing each address number with the words after it.

    "319 High Street, Roxboro" gives {"319 high", "319 st"}. Each word of the
    address is common on its own ("high", "st", a town name), but a number
    next to its street word picks out one building, whatever order the other
    components appear in and whatever script the business name is written in.
    Numbers lose leading zeros ("0710" -> "710"); runs over 6 digits are
    phone-like and skipped.
    """
    return number_word_keys_from_tokens(normalize_name(address).split(), span, min_len)


def number_word_keys_from_tokens(toks, span: int = 2, min_len: int = 1) -> frozenset:
    """number_word_keys on an already normalized, split address.

    Words shorter than min_len are skipped when pairing, so street-type and
    function words ("rue", "de", "st") give way to the street name itself.
    """
    out = set()
    for i, tok in enumerate(toks):
        if not (tok.isdigit() and len(tok) <= 6):
            continue
        num, taken = str(int(tok)), 0
        for nxt in toks[i + 1:]:
            if nxt.isdigit() or len(nxt) < min_len:
                continue
            out.add(f"{num} {nxt}")
            taken += 1
            if taken == span:
                break
    return frozenset(out)


def hash64(text: str) -> int:
    """Stable 64-bit hash of a string, identical across processes and runs.

    Python's built-in hash() is randomized per process, so it cannot be cached
    to disk; blake2b gives a reproducible digest instead. Returns 0 for the
    empty string so callers can treat "no usable key" as a single sentinel.
    """
    if not text:
        return 0
    return int.from_bytes(hashlib.blake2b(text.encode("utf-8"), digest_size=8).digest(),
                          "little", signed=True)
