"""Pairwise matcher: candidates -> features -> LightGBM -> admission -> assignment.

The blocking ceiling says a perfect matcher over address-plus-name candidates
would score about 0.89. This turns that ceiling into an actual score.

Four stages:
  1. Candidates from the cached token postings (name tokens, address tokens,
     address number-word keys, whole-name keys, house numbers), within country.
  2. Features per candidate pair, from the raw name and address text.
  3. A LightGBM classifier trained on labelled pairs, with isotonic calibration
     fitted on a separate slice of training entities so the probabilities can
     feed the admission bar directly (--no-calibrate keeps the raw output).
  4. Per-entity admission under the metric's own rule, then a one-to-one pass:
     every target record belongs to at most one Source 1 entity, so a target
     claimed by two entities is kept only by the one that scores it highest.

Admission follows from F0.5 = 1.25c / (n + 0.25k): adding a candidate of
probability p raises the expected score only while p exceeds the current score
divided by 1.25, so the bar rises with each id admitted.

Run:
    python src/pair_model.py --entities 40000 --max-df 300
"""
import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import config as C
from src import er_io
from src.candidates import build_token_postings, lookup_postings
from src.er_norm import (hash64, house_numbers, normalize_name, number_word_keys,
                         number_word_keys_from_tokens, postcodes)

ENCODE = 2_000_000_000

# Token postings families: name tokens, address tokens, and address number-word
# keys that skip words under 4 characters ("36 rue de segur" -> "36 segur").
TOKEN_FIELDS = (1, 2, "nw4")
THRESHOLDS = (0.5, 0.6, 0.7)
NW_MIN_LEN = 4


def sample_entities(n: int, seed: int):
    """Fixed sample of Source 1 rows with their true match sets."""
    rng = np.random.default_rng(seed)
    s1 = er_io.parse_source("train", 1)
    gt = er_io.parse_ground_truth()
    rows = np.sort(rng.choice(len(s1["ids"]), size=min(n, len(s1["ids"])), replace=False))
    row_of = er_io.index_of(s1["ids"], gt["s1"])
    gt_of_row = np.full(len(s1["ids"]), -1, dtype=np.int64)
    gt_of_row[row_of] = np.arange(len(gt["s1"]))
    truth = {}
    for row in rows.tolist():
        g = gt_of_row[row]
        lo, hi = gt["offsets"][g], gt["offsets"][g + 1]
        truth[row] = set((gt["match_src"][lo:hi].astype(np.int64) * ENCODE
                          + gt["match_id"][lo:hi]).tolist())
    return s1, rows, truth


def build_index(split: str, max_df: int) -> dict:
    """Sorted blocking keys for both target sources, built once per split.

    Per source: whole-name and token-sorted keys, house-number postings, and
    the token postings in TOKEN_FIELDS, all folded with the country.
    """
    index = {}
    for source in (2, 3):
        target = er_io.parse_source(split, source)
        ctry_t = er_io.country_keys(target)
        entry = {}
        for col in ("name_key", "sort_key"):
            tk = er_io.combine_keys(target[col], ctry_t)
            order = np.argsort(tk, kind="stable")
            entry[col] = (tk[order], order)

        hr, hk = [], []
        for slot in range(target["house"].shape[1]):
            v = target["house"][:, slot]
            keep = np.flatnonzero(v != er_io.EMPTY)
            hr.append(keep.astype(np.int32))
            hk.append(er_io.combine_keys(v[keep].astype(np.int64), ctry_t[keep]))
        hkey = np.concatenate(hk)
        hrow = np.concatenate(hr)
        o = np.argsort(hkey, kind="stable")
        entry["house"] = (hkey[o], hrow[o])

        for field in TOKEN_FIELDS:
            entry[f"tok{field}"] = build_token_postings(split, source, max_df, field=field)
        index[source] = entry
        del target
    return index


def read_s1_text(split: str, rows) -> dict:
    """Raw (name, address) for the given Source 1 rows, from one streaming pass."""
    want = set(rows.tolist())
    text = {}
    with open(C.source_file(split, 1), encoding="utf-8") as f:
        next(f, None)
        for i, line in enumerate(f):
            if i in want:
                p = line.rstrip("\n").split("\t")
                if len(p) == 4:
                    text[i] = (p[1], p[2])
                if len(text) == len(want):
                    break
    return text


def _query_tokens(field, name: str, address: str):
    """The Source 1 side's tokens for one postings family."""
    if field == "nw4":
        return number_word_keys(address, min_len=NW_MIN_LEN)
    return normalize_name(name if field == 1 else address).split()


def gather(rows, s1, ctry_s1, text, index, max_group: int):
    """Candidate target rows per entity from a prebuilt index.

    Returns {s1_row: {source: set(target_row)}} using whole-name, token-sorted,
    house-number, name-token, address-token and number-word keys, all within
    country.
    """
    out = {r: {} for r in rows.tolist()}
    for source in (2, 3):
        e = index[source]
        for r in rows.tolist():
            out[r][source] = set()

        for col in ("name_key", "sort_key"):
            sk, order = e[col]
            qk = er_io.combine_keys(s1[col][rows], ctry_s1[rows])
            for i, hits in enumerate(lookup_postings(sk, order, qk, max_group)):
                if len(hits):
                    out[int(rows[i])][source] |= set(hits.tolist())

        hkey, hrow = e["house"]
        for slot in range(s1["house"].shape[1]):
            v = s1["house"][rows, slot]
            live = v != er_io.EMPTY
            qk = er_io.combine_keys(v.astype(np.int64), ctry_s1[rows])
            for i, hits in enumerate(lookup_postings(hkey, hrow, qk, max_group)):
                if live[i] and len(hits):
                    out[int(rows[i])][source] |= set(hits.tolist())

        for field in TOKEN_FIELDS:
            tkey, trow = e[f"tok{field}"]
            for i, r in enumerate(rows.tolist()):
                toks = sorted({hash64(t) for t in _query_tokens(field, *text[r])})
                if not toks:
                    continue
                qk = er_io.combine_keys(np.array(toks, dtype=np.int64),
                                        np.full(len(toks), ctry_s1[r], dtype=np.int64))
                for hits in lookup_postings(tkey, trow, qk, max_group):
                    if len(hits):
                        out[r][source] |= set(hits.tolist())
    return out


def gather_candidates(rows, s1, max_df: int, max_group: int, split="train"):
    """Candidate target rows per sampled entity, plus the entities' raw text."""
    text = read_s1_text(split, rows)
    index = build_index(split, max_df)
    return gather(rows, s1, er_io.country_keys(s1), text, index, max_group), text


FEATURES = ["name_jac", "name_cont", "name_eq", "name_sort_eq", "name_len_ratio",
            "addr_jac", "addr_cont", "addr_eq", "house_hit", "pc_hit",
            "name_char_jac", "addr_char_jac", "n_cand", "best_rank", "nw_shared",
            "addr_empty_s1", "addr_empty_t", "name_nonlatin_s1", "name_nonlatin_t",
            "num_jac", "num_cont", "num_both", "name_only_s1", "name_only_t"]


def _nonlatin(s: str) -> float:
    """1.0 when a normalized string holds non-ASCII letters (Devanagari, Bengali, ...)."""
    return float(any(ord(c) > 127 and c.isalpha() for c in s))


def _jac(a: set, b: set):
    """Jaccard and containment of two token sets."""
    if not a or not b:
        return 0.0, 0.0
    inter = len(a & b)
    return inter / len(a | b), inter / min(len(a), len(b))


def _chars(s: str, n=3):
    """Character n-gram set, for typo tolerance."""
    s = f"  {s} "
    return {s[i:i + n] for i in range(len(s) - n + 1)}


def build_features(cands, s1_text, targets_text):
    """Feature matrix for every candidate pair, plus its (s1_row, source, target_row)."""
    feats, keys = [], []
    for r, per_source in cands.items():
        n_cand = sum(len(v) for v in per_source.values())
        ln, la = normalize_name(s1_text[r][0]), normalize_name(s1_text[r][1])
        ltn, lta = set(ln.split()), set(la.split())
        lcn, lca = _chars(ln), _chars(la)
        lh, lp = house_numbers(s1_text[r][1]), postcodes(s1_text[r][1])
        lnw = number_word_keys_from_tokens(la.split(), min_len=NW_MIN_LEN)
        l_nl = _nonlatin(ln)
        for source, rows in per_source.items():
            for tr in rows:
                rn, ra = targets_text[source][tr]
                nn, na = normalize_name(rn), normalize_name(ra)
                rtn, rta = set(nn.split()), set(na.split())
                nj, nc = _jac(ltn, rtn)
                aj, ac = _jac(lta, rta)
                ncj, _ = _jac(lcn, _chars(nn))
                acj, _ = _jac(lca, _chars(na))
                th = house_numbers(ra)
                nums = len(lh & th)
                feats.append((
                    nj, nc, float(ln == nn),
                    float(" ".join(sorted(ltn)) == " ".join(sorted(rtn))),
                    min(len(ln), len(nn)) / max(len(ln), len(nn), 1),
                    aj, ac, float(la == na),
                    float(bool(nums)),
                    float(bool(lp & postcodes(ra))),
                    ncj, acj, float(n_cand), 0.0,
                    float(len(lnw & number_word_keys_from_tokens(na.split(),
                                                                 min_len=NW_MIN_LEN))),
                    # Missing text is not disagreement: a blank address or a
                    # name in another script zeroes the similarities above,
                    # and these flags let the model lean on the other field.
                    float(not la), float(not na), l_nl, _nonlatin(nn),
                    # Sibling records differ by one number ("25-112" vs
                    # "25-133"); one shared number is not agreement.
                    nums / len(lh | th) if lh and th else 0.0,
                    nums / len(lh) if lh else 0.0,
                    float(bool(lh) and bool(th)),
                    float(len(ltn - rtn)), float(len(rtn - ltn))))
                keys.append((r, source, tr))
    return np.array(feats, dtype=np.float32), keys




GROUP_BASE = ("name_char_jac", "addr_char_jac")
GROUP_FEATURES = [f"{f}_{kind}" for f in GROUP_BASE for kind in ("gap", "rank")]


def add_group_features(X, keys):
    """Append each GROUP_BASE similarity's gap to the entity's best and its rank.

    Computed over the entity's pre-ranked candidates, so train and test see the
    same set. Being the closest of ~50 candidates says more than an absolute
    similarity does; judged under the threshold rule this is worth about
    +0.007 held out (it looked harmful only under greedy admission).
    """
    if not len(keys):
        return np.zeros((0, X.shape[1] + len(GROUP_FEATURES)), dtype=np.float32)
    ent = np.fromiter((k[0] for k in keys), dtype=np.int64, count=len(keys))
    _, g = np.unique(ent, return_inverse=True)
    cols = []
    for f in GROUP_BASE:
        col = X[:, FEATURES.index(f)].astype(np.float64)
        best = np.full(g.max() + 1, -np.inf)
        np.maximum.at(best, g, col)
        order = np.lexsort((-col, g))
        sg = g[order]
        first = np.r_[0, np.flatnonzero(np.diff(sg)) + 1]
        within = np.arange(len(col)) - np.repeat(first, np.diff(np.r_[first, len(col)]))
        rank = np.empty(len(col))
        rank[order] = within
        cols += [col - best[g], rank]
    return np.hstack([X, np.column_stack(cols).astype(np.float32)])


def prefilter(X, keys, k):
    """Keep each entity's k candidates with the highest name + address trigram overlap.

    This is the last blocking stage: the matcher is trained and run only on
    what survives, and candidate_pairs.tsv lists exactly that set. Dropping
    the long tail of easy negatives also scores higher than keeping it (on the
    25k sample, top 50 of ~290 kept 98.7% of true pairs). Order is preserved;
    ties go to the earlier row. k=None keeps everything.
    """
    if k is None or not len(keys):
        return X, keys
    s = X[:, FEATURES.index("addr_char_jac")] + X[:, FEATURES.index("name_char_jac")]
    ent = np.fromiter((kk[0] for kk in keys), dtype=np.int64, count=len(keys))
    _, g = np.unique(ent, return_inverse=True)
    order = np.lexsort((-s, g))
    sg = g[order]
    first = np.r_[0, np.flatnonzero(np.diff(sg)) + 1]
    within = np.arange(len(s)) - np.repeat(first, np.diff(np.r_[first, len(s)]))
    rank = np.empty(len(s), dtype=np.int64)
    rank[order] = within
    keep = np.flatnonzero(rank < k)
    return X[keep], [keys[i] for i in keep]


def build_features_parallel(cands, s1_text, targets_text, pool=None, workers=1):
    """build_features split by entity across a process pool.

    Chunks keep the entity order, so rows come back in the same order as the
    serial call and the matrix is identical.
    """
    if pool is None or workers <= 1:
        return build_features(cands, s1_text, targets_text)
    ents = list(cands)
    size = max(1, -(-len(ents) // (workers * 4)))
    jobs = []
    for i in range(0, len(ents), size):
        part = ents[i:i + size]
        tt = {s: {tr: targets_text[s][tr] for r in part for tr in cands[r].get(s, ())}
              for s in (2, 3)}
        jobs.append(({r: cands[r] for r in part}, {r: s1_text[r] for r in part}, tt))
    parts = [p for p in pool.starmap(build_features, jobs) if p[1]]
    if not parts:
        return np.zeros((0, len(FEATURES)), dtype=np.float32), []
    return (np.concatenate([p[0] for p in parts]),
            [k for p in parts for k in p[1]])


def fetch_target_text(cands, split="train"):
    """Raw name and address for every candidate target row, one pass per source."""
    out = {}
    for source in (2, 3):
        rows = sorted({tr for per in cands.values() for tr in per.get(source, ())})
        out[source] = er_io.fetch_fields(split, source, np.array(rows, dtype=np.int64)) \
            if rows else {}
    return out


def admit(probs, ids, k_hat):
    """Greedy admission under F0.5: add while p > current score / 1.25.

    From F = 1.25c / (n + 0.25k), admitting a candidate of probability p raises
    the expected score only while p exceeds c / (n + 0.25k), so the bar rises
    with every id already admitted. c is accumulated as the sum of admitted
    probabilities, which is the expected number correct.
    """
    order = np.argsort(-probs)
    chosen, c, n = [], 0.0, 0
    for idx in order:
        p = probs[idx]
        if n and p <= c / (n + 0.25 * k_hat):
            break
        chosen.append(ids[idx])
        c += p
        n += 1
    return chosen


def select(by_ent, k_global=None):
    """Admit per entity, then keep each target only for its highest scorer.

    by_ent maps s1_row to a list of (probability, encoded target id). With
    k_global unset, k is estimated per entity as the sum of its probabilities,
    the expected number of true matches among its candidates; that needs
    calibrated probabilities. Returns (admitted, assigned), both
    {s1_row: [encoded id]}.
    """
    picks = {}
    for r, lst in by_ent.items():
        probs = np.array([x[0] for x in lst])
        ids = [x[1] for x in lst]
        k_hat = k_global if k_global is not None else max(float(probs.sum()), 1.0)
        picks[r] = admit(probs, ids, k_hat)

    best = {}
    for r, chosen in picks.items():
        lookup = {i: pr for pr, i in by_ent[r]}
        for i in chosen:
            if i not in best or lookup[i] > best[i][1]:
                best[i] = (r, lookup[i])
    assigned = {r: [] for r in picks}
    for i, (r, _) in best.items():
        assigned[r].append(i)
    return picks, assigned


def macro_f05(truth, pred, entities):
    """Mean per-entity F0.5 over the given entities; empty-empty scores 1.0."""
    tot = 0.0
    for r in entities:
        t, q = truth[r], set(pred.get(r, ()))
        if not t and not q:
            tot += 1.0
        elif t and q:
            c = len(t & q)
            tot += 1.25 * c / (len(q) + 0.25 * len(t)) if c else 0.0
    return tot / len(entities)


def fit(n_entities: int, max_df: int, max_group: int, calibrate=True, pool=None, workers=1,
        top_k=None):
    """Train on one entity split and score the held-out split end to end.

    top_k applies prefilter before training. Returns a dict with the
    booster, the isotonic calibrator (or None), the global k used when
    uncalibrated, and the held-out scores.
    """
    t0 = time.time()
    import lightgbm as lgb

    s1, rows, truth = sample_entities(n_entities, C.SEED)
    print(f"entities: {len(rows):,} | mean true matches "
          f"{np.mean([len(v) for v in truth.values()]):.3f}", flush=True)

    cands, s1_text = gather_candidates(rows, s1, max_df, max_group)
    tgt_text = fetch_target_text(cands)
    print(f"candidates gathered ({time.time() - t0:.0f}s), "
          f"{sum(len(v) for p in cands.values() for v in p.values()):,} pairs", flush=True)

    X, keys = build_features_parallel(cands, s1_text, tgt_text, pool, workers)
    del tgt_text
    n_raw = len(keys)
    X, keys = prefilter(X, keys, top_k)
    X = add_group_features(X, keys)
    tid = {s: er_io.parse_source("train", s)["ids"] for s in (2, 3)}
    y = np.array([1 if (src * ENCODE + tid[src][tr]) in truth[r] else 0
                  for r, src, tr in keys], dtype=np.int8)
    print(f"features: {X.shape} of {n_raw:,} raw pairs | positives {y.sum():,} ({y.mean() * 100:.2f}%) "
          f"({time.time() - t0:.0f}s)", flush=True)

    ent = np.array([k[0] for k in keys])
    uniq_ent = np.unique(ent)
    rng = np.random.default_rng(C.SEED)
    holdout = set(rng.choice(uniq_ent, size=len(uniq_ent) // 4, replace=False).tolist())
    is_val = np.array([e in holdout for e in ent])

    iso, k_global = None, None
    if calibrate:
        # Split the training entities again so calibration never sees the data
        # the trees were fitted on; an uncalibrated score would bias the bar.
        train_ent = np.array(sorted(set(uniq_ent.tolist()) - holdout))
        calib_ent = set(rng.choice(train_ent, size=max(len(train_ent) // 5, 1),
                                   replace=False).tolist())
        is_cal = np.array([e in calib_ent for e in ent])
        fit_mask = ~is_val & ~is_cal
    else:
        fit_mask = ~is_val
        k_global = float(np.mean([len(truth[r]) for r in rows.tolist() if r not in holdout]))

    model = lgb.train(
        {"objective": "binary", "learning_rate": 0.1, "num_leaves": 63,
         "min_data_in_leaf": 50, "verbose": -1, "seed": C.SEED},
        lgb.Dataset(X[fit_mask], label=y[fit_mask]), num_boost_round=300)
    p = model.predict(X[is_val])
    if calibrate:
        from sklearn.isotonic import IsotonicRegression
        iso = IsotonicRegression(out_of_bounds="clip", y_min=0.0, y_max=1.0)
        iso.fit(model.predict(X[is_cal]), y[is_cal])
        p = iso.predict(p)
    print(f"model trained ({time.time() - t0:.0f}s)", flush=True)

    val_keys = [k for k, v in zip(keys, is_val) if v]
    by_ent = {}
    for (r, src, tr), prob in zip(val_keys, p):
        by_ent.setdefault(r, []).append((prob, src * ENCODE + tid[src][tr]))
    picks, assigned = select(by_ent, k_global)

    raw, one2one = macro_f05(truth, picks, holdout), macro_f05(truth, assigned, holdout)
    # A flat probability threshold beats greedy admission on uncalibrated
    # scores, so the held-out score is also reported under that rule.
    thr = {t: macro_f05(truth, {r: [i for pr, i in lst if pr >= t] for r, lst in by_ent.items()},
                        holdout) for t in THRESHOLDS}
    imp = sorted(zip(FEATURES + GROUP_FEATURES, model.feature_importance("gain")),
                 key=lambda x: -x[1])
    return {"model": model, "iso": iso, "k_global": k_global, "top_k": top_k,
            "entities": len(rows), "holdout": len(holdout), "pairs": int(X.shape[0]),
            "positive_rate": float(y.mean()), "macro_f05_greedy": raw,
            "macro_f05_one_to_one": one2one, "macro_f05_threshold": thr, "feature_gain": imp,
            "seconds": time.time() - t0}


def main(n_entities: int, max_df: int, max_group: int, out_dir, calibrate=True,
         workers=1, top_k=None) -> None:
    """Fit, report the held-out score, and write it to out_dir."""
    from multiprocessing import get_context
    pool = get_context("spawn").Pool(workers) if workers > 1 else None
    try:
        res = fit(n_entities, max_df, max_group, calibrate, pool, workers, top_k)
    finally:
        if pool is not None:
            pool.close()
    print(f"\nheld-out entities: {res['holdout']:,}")
    print(f"  macro F0.5, greedy admission:      {res['macro_f05_greedy']:.5f}")
    print(f"  macro F0.5, + one-to-one assign:   {res['macro_f05_one_to_one']:.5f}")
    for t, v in res["macro_f05_threshold"].items():
        print(f"  macro F0.5, prob >= {t:.2f}:          {v:.5f}")
    print("\n  top features by gain: " + ", ".join(
        f"{n} {g:.0f}" for n, g in res["feature_gain"][:6]))
    print(f"\ntotal {res['seconds']:.0f}s")

    if out_dir:
        pth = Path(out_dir) / "pair_model.json"
        pth.parent.mkdir(parents=True, exist_ok=True)
        pth.write_text(json.dumps(
            {"entities": res["entities"], "max_df": max_df, "max_group": max_group,
             "calibrated": calibrate, "top_k": top_k, "pairs": res["pairs"],
             "positive_rate": res["positive_rate"],
             "macro_f05_greedy": res["macro_f05_greedy"],
             "macro_f05_one_to_one": res["macro_f05_one_to_one"],
             "macro_f05_threshold": {str(t): v for t, v in res["macro_f05_threshold"].items()},
             "feature_gain": {n: float(g) for n, g in res["feature_gain"]}}, indent=2),
            encoding="utf-8")
        print(f"wrote {pth}")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--entities", type=int, default=40000)
    p.add_argument("--max-df", type=int, default=300)
    p.add_argument("--max-group", type=int, default=200)
    p.add_argument("--out", default="results/pair_model")
    p.add_argument("--no-calibrate", action="store_true",
                   help="raw booster output with one global k (the pre-calibration rule)")
    p.add_argument("--workers", type=int, default=1, help="processes for feature building")
    p.add_argument("--top-k", type=int, default=50,
                   help="candidates kept per entity by the pre-ranker (0 keeps all)")
    a = p.parse_args()
    main(a.entities, a.max_df, a.max_group, a.out, not a.no_calibrate, a.workers,
         a.top_k or None)
