# Business Entity Resolution — pipeline

Reproduces `output/matching_results.tsv` and `output/candidate_pairs.tsv` from the
challenge dataset.

## Layout

```
business_entity_resolution/
├── config.py          paths, column names, run settings (single source of truth)
├── requirements.txt   pinned dependencies
└── src/
    ├── er_norm.py         name normalization and address feature extraction
    ├── er_io.py           streaming readers: TSV -> compact numpy arrays
    ├── eda_er.py          data report (counts, match distribution, blocking recall)
    ├── metrics.py         F0.5 scorer, per entity and macro-averaged
    ├── candidates.py      token postings (name, address, number-word keys) and blocking ceilings
    ├── pair_model.py      candidates -> pair features -> pre-ranker -> LightGBM -> admission
    ├── predict_matches.py fits the matcher, scores a whole split and dumps every pair score
    ├── decide.py          applies the final decision rule to the dumped scores; writes both TSVs
    ├── decision_rules.py  compares decision rules offline against training labels
    ├── baseline_exact.py  first baseline: exact-name rule
    ├── blocking_ceiling.py  ceiling of each blocking key family under a perfect matcher
    └── log_experiment.py  appends one row per run to experiments.csv
```

## Setup

```bash
python -m venv .venv && . .venv/bin/activate    # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

Point the code at the dataset. Either place it at `./data/student_resource/` or set:

```bash
export ER_DATA_DIR=/path/to/folder/containing/student_resource
```

The expected layout underneath is the one shipped with the challenge:

```
student_resource/dataset/train/train_source{1,2,3}.tsv
student_resource/dataset/train/train_ground_truth.tsv
student_resource/dataset/test/test_source{1,2,3}.tsv
```

## Reproduce

```bash
# 1. Data report. Also builds the parsed-array cache under outputs/cache/.
python src/eda_er.py --out results/eda

# 2. Held-out score of the matcher (fits on 75% of a 60,000-entity training
#    sample, scores the other 25% end to end). About 3 minutes on 8 cores.
python src/pair_model.py --entities 60000 --no-calibrate --top-k 50 --workers 8

# 3. Fit the same matcher, score every test candidate pair and dump the scores.
#    About 1 hour on 8 cores; the first run also builds the token caches.
python src/predict_matches.py --split test --entities 60000 --no-calibrate \
    --top-k 50 --workers 8 --dump-scores outputs/scores/test_f28 --run-name sub03_f28

# 4. Apply the decision rule to the dumped scores and write both output files.
python src/decide.py --scores outputs/scores/test_f28 --split test \
    --rule argmax_threshold --threshold 0.70 --run-name sub03_final
```

Step 4 writes `matching_results.tsv` and `candidate_pairs.tsv` to
`outputs/submissions/sub03_final/`. These are the files in `output/`.
The fitted booster is saved to `outputs/models/sub03_f28/`.

Validate them with the organizers' script before submitting:

```bash
python3 utils/validate_submission.py \
    --matching output/matching_results.tsv \
    --candidate output/candidate_pairs.tsv \
    --test-dir dataset/test
```

## How it works

**Normalization** (`er_norm.py`). Names are lowercased, stripped of accents and
punctuation, and rewritten through a small abbreviation table so that
`Corporation`/`Corp`, `Private Limited`/`Pvt Ltd`, `Road`/`Rd` and `&`/`and`
collapse to one spelling. A trailing URL is dropped, except when the name is
nothing but a domain, in which case the domain body is kept as the name (about
3.5% of Source 2). Address features are digit runs: any run of 1-6 digits is a
candidate house number (leading zeros dropped, so `008138` equals `8138`), and a
run of exactly 5 or 6 digits is a candidate postal code. Both rules are written
against shapes that occur in every country in the data; nothing keys on the
country label itself.

**Representation** (`er_io.py`). The dataset is 24M records across six files, far
too much to hold as strings. Each file is read once, line by line, and reduced to
four fixed-width arrays: the numeric part of the entity id, a country code, a
64-bit hash of the normalized name and a 64-bit hash of the token-sorted name.
Hashes use blake2b rather than Python's `hash()` so they are reproducible across
processes and can be cached to disk. Raw text for a chosen subset of rows is
re-read on demand, which keeps peak memory proportional to the subset rather than
the file.

Country codes are per file (assigned in first-seen order), so they are converted
to a hash of the label before any cross-file comparison.

**Candidate generation** (`pair_model.py`, `candidates.py`). All blocking is
within country. For each Source 1 record, a Source 2 or Source 3 record becomes a
candidate when it shares any of these keys, and the key's group is small enough
to be informative (at most 200 records; tokens in more than 300 records of a
source are not indexed):

- the whole normalized name, or its alphabetically sorted tokens;
- a house number;
- any name token, or any address token;
- a number-word key: each address number paired with the next two address
  words of 4+ characters (`319 High Street, Roxboro` gives `319 high` and
  `319 roxboro`; `36 Rue de Ségur` gives `36 segur`).

The number-word key matters most. Every single word of a typical address
(`high`, `st`, a town name) is too common to block on, so records at the same
building with a reworded or foreign-script name were never compared. A number
next to its street word identifies the building regardless of component order,
zero padding or the script the name is written in. On a 25,000-entity training
sample it raised the share of true pairs reachable from 80.3% to 91.9%.

This yields about 265 candidates per entity. A pre-ranker then keeps the 50 with
the highest name + address character-trigram overlap. Those 50 are what the
matcher scores and what `candidate_pairs.tsv` lists; they keep 98.7% of the
reachable true pairs.

**Matching** (`pair_model.py`). Each candidate pair gets 28 features: name and
address token Jaccard and containment, character-trigram Jaccard for both,
exact and token-sorted name equality, name length ratio, exact address
equality, shared house number, shared postal code, shared number-word keys, the
entity's candidate count, and a group aimed at the errors the first model made:
whether either address is blank, whether either name is written in a non-Latin
script, the Jaccard and containment of the two addresses' number sets, and the
count of name tokens unique to each side. The blank and script flags matter
because a missing address or a Devanagari name otherwise reads as total
disagreement; the number-set features matter because sibling records at the
same site differ by one number ("25-112" vs "25-133") while still sharing
another. The last four features place a pair within its entity: for name and
address trigram overlap, the gap to the entity's best candidate and the rank
among its (pre-ranked) candidates, since being the closest of ~50 candidates
says more than an absolute similarity. A LightGBM binary classifier is trained
on labelled pairs from 60,000 training entities.

**Choosing the match set** (`decide.py`). Every Source 2/3 record belongs to at
most one Source 1 entity in the training data (no exceptions in 7.6M matches),
so each scored record is first assigned to the single entity that scores it
highest. An entity then keeps every assigned record with probability at least
0.70. A flat threshold beat the greedy rule derived from the metric identity
F0.5 = 1.25c / (n + 0.25k) on out-of-fold scores (the greedy rule needs
calibrated probabilities, which boosted scores are not). 0.60 and 0.70 tie
within a country; 0.70 is used because leave-one-country-out runs (train on one
country, score the other) move the best threshold upward for an unseen country,
and the test set includes one.

**Scoring** (`metrics.py`). F0.5 is computed per Source 1 entity and averaged
over all of them, matching the challenge definition. An entity with no true
matches scores 1.0 for a correct empty prediction and 0.0 otherwise.
